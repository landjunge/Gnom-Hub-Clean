import uuid, re, subprocess; from datetime import datetime; from fastapi import APIRouter; from .db import get_db, save_db
router = APIRouter()
def _post_chat(s, c): save_db("memory", get_db("memory") + [{"id":str(uuid.uuid4()),"agent_id":"war-room","content":c,"metadata":{"type":"role_response","sender":s},"timestamp":datetime.utcnow().isoformat()+"Z"}])
def handle_idea(t): save_db("ideas", get_db("ideas") + [{"id":str(uuid.uuid4()),"content":t,"ts":datetime.utcnow().isoformat()+"Z"}]); return {"status": "idea_saved"}
def handle_clear(q=""):
    q = q.strip().lower()
    if q == "all agents":
        sys_ags = ['watchdogag','skillsag','backupag','cronjobag','soulag']
        save_db("agents", [a for a in get_db("agents") if a["name"].lower() in sys_ags])
        _post_chat("System", "Alle externen Agenten (inklusive Hermes) wurden gelöscht. System-Infrastruktur bleibt intakt.")
        return {"status": "agents_cleared"}
    
    from .db import get_active_project
    p = get_active_project()
    
    if q == "@projekt":
        save_db("memory", [m for m in get_db("memory") if not (m.get("agent_id") == "war-room" and m.get("project", "default") == p)])
        import os, shutil
        from .routes_workspace import get_workspace_dir
        wd = get_workspace_dir()
        for f in os.listdir(wd):
            fp = os.path.join(wd, f)
            if os.path.isfile(fp): os.unlink(fp)
            elif os.path.isdir(fp): shutil.rmtree(fp)
        _post_chat("System", f"Projekt '{p}' komplett geleert (Chat + Workspace-Dateien gelöscht).")
        return {"status": "project_cleared"}
        
    if q.startswith("chat"):
        parts = q.split()
        if len(parts) > 1:
            target_agent = parts[1].replace("@", "").lower()
            save_db("memory", [m for m in get_db("memory") if not (m.get("agent_id") == "war-room" and m.get("project", "default") == p and m.get("metadata", {}).get("sender", "").lower() == target_agent)])
            _post_chat("System", f"Chat-Historie von Agent '{target_agent}' im Projekt '{p}' gelöscht.")
        else:
            save_db("memory", [m for m in get_db("memory") if not (m.get("agent_id") == "war-room" and m.get("project", "default") == p)])
            _post_chat("System", f"Kompletter Chat im Projekt '{p}' gelöscht.")
        return {"status": "cleared"}
        
    # Fallback Standard: Clear all chat for the active project
    save_db("memory", [m for m in get_db("memory") if not (m.get("agent_id") == "war-room" and m.get("project", "default") == p)])
    return {"status": "cleared"}
def handle_status(): return {"agents": [{"name":a["name"],"role":a.get("role","—"),"st":a.get("skill",a.get("status"))} for a in get_db("agents")]}
def handle_free(q): ags=get_db("agents"); t=q.replace("@","").strip().lower(); [a.update({"active_job":""}) for a in ags if not t or a["name"].lower()==t]; save_db("agents", ags); _post_chat("System", f"Jobs cleared: {t or 'ALL'}"); return {"status": "ok"}
def handle_skill(q):
    from .role_tools import _llm; ags = get_db("agents"); a = next((x for x in ags if x["name"].lower() == q.replace("@","").strip().lower()), None)
    if a: a["skill"] = _llm("SYSTEM: Max 3 Wörter.", a.get("description",""), 50).strip(); save_db("agents", ags); _post_chat("Skill", f"@{a['name']}: {a['skill']}")
    return {"status": "ok"}
def handle_job(task):
    from .role_tools import distribute_job; ags = get_db("agents"); gen = next((a for a in ags if a.get("role") == "general"), None)
    if not gen: return {"error": "Kein General"}
    save_db("jobs", get_db("jobs") + [{"id": str(uuid.uuid4()), "task": task, "general": gen["name"], "status": "open", "ts": datetime.utcnow().isoformat()+"Z"}]); res = distribute_job(task); _post_chat(gen["name"], res)
    [a.update({"active_job": next((m.group(2).strip() for m in re.finditer(r'@(\w+)[\s-→>:]+(.+)', res) if m.group(1).lower()==a["name"].lower()), "")}) for a in ags]; save_db("agents", ags); return {"status": "job_created"}
def handle_sandbox(c):
    open("sandbox.py", "w").write(c.replace("```python", "").replace("```", "").strip())
    try: out = subprocess.run(["python3", "sandbox.py"], capture_output=True, text=True, timeout=5).stdout
    except Exception as e: out = str(e)
    _post_chat("Sandbox", f"Output:\n```\n{out[:500]}\n```"); return {"status": "executed"}
def handle_summary(q=""): from .role_tools import summarize_chat; _post_chat("Summarizer", summarize_chat()); return {"status": "summarized"}
def handle_checkpoint(q):
    from .swarm_checkpoint import save_swarm_checkpoint as S, load_latest_checkpoint as L; c=L()
    _post_chat("System", S(get_db("agents"), get_db("memory"))) if "save" in q else (save_db("agents", c["souls"]), save_db("memory", c["war_room_state"]), _post_chat("System", "Restored")) if "restore" in q and c else None
    return {"status": "ok"}
def handle_git(q, rb=False):
    from .gitAG import git_cmd; p = q.split(" ", 1); cmd = f"reset --hard {p[1]}" if rb else (p[1] if len(p)>1 else "")
    if p: _post_chat("System", f"Git:\n```\n{git_cmd(p[0], cmd)[:500]}\n```"); handle_checkpoint("restore") if rb else None
    return {"status": "ok"}
@router.get("/api/ideas")
def get_ideas(): return get_db("ideas")
@router.get("/api/jobs")
def get_jobs(): return sorted(get_db("jobs"), key=lambda j: j.get("ts",""), reverse=True)[:20]
@router.put("/api/agents/{agent_id}/group")
def set_group(aid: str, grp: str = ""):
    ags=get_db("agents"); a=next((x for x in ags if x["id"]==aid), None)
    if a: a["group"]=grp; save_db("agents", ags)
    return {"agent": a["name"]} if a else {"error": "Not found"}
